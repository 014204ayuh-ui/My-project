"""One-time training: map heart-disease CSV → 4 sensor features, fit RF, dump pkl.

Dataset does not natively contain SpO2 or ADM. Those two features are
SIMULATED and correlated with the label for training only — not clinically
valid. State this in any report; do not overclaim.
"""

from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "heart_dataset.csv"
MODEL_PATH = ROOT / "trained_model.pkl"
SCALER_PATH = ROOT / "scaler.pkl"

RANDOM_STATE = 42


def _col(df: pd.DataFrame, *names: str) -> str:
    lower = {c.lower(): c for c in df.columns}
    for name in names:
        if name.lower() in lower:
            return lower[name.lower()]
    raise KeyError(f"none of {names} found in {list(df.columns)}")


def build_features(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    hb_col = _col(df, "thalachh", "thalach")
    oldpeak_col = _col(df, "oldpeak")
    y_col = _col(df, "output", "target")
    exng_col = _col(df, "exng", "exang")

    rng = np.random.default_rng(RANDOM_STATE)
    y = df[y_col].astype(int)

    hb = df[hb_col].astype(float)
    temp = 36.5 + df[oldpeak_col].astype(float) * 0.3
    spo2 = 98.0 - (y.to_numpy() * rng.uniform(2.0, 12.0, len(df)))
    adm = (df[exng_col].astype(int) == 0).astype(int)

    X = pd.DataFrame(
        {
            "spo2": spo2,
            "hb": hb,
            "adm": adm,
            "temp": temp,
        }
    )
    return X, y


def main() -> None:
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"missing dataset: {DATA_PATH}")

    df = pd.read_csv(DATA_PATH)
    X, y = build_features(df)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )

    scaler = StandardScaler().fit(X_train.to_numpy())
    X_train_scaled = scaler.transform(X_train.to_numpy())
    X_test_scaled = scaler.transform(X_test.to_numpy())

    model = RandomForestClassifier(
        n_estimators=100, max_depth=8, random_state=RANDOM_STATE
    )
    model.fit(X_train_scaled, y_train.to_numpy())

    print(classification_report(y_test.to_numpy(), model.predict(X_test_scaled)))

    joblib.dump(model, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)
    print(f"wrote {MODEL_PATH.name} and {SCALER_PATH.name}")


if __name__ == "__main__":
    main()
