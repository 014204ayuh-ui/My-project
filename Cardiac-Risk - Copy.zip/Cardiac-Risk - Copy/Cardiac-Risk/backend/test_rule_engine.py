"""Spec test cases for rule_engine.evaluate_reading. Stdlib unittest."""

import unittest

from rule_engine import VERDICT_CRITICAL, VERDICT_MODERATE, VERDICT_NORMAL, evaluate_reading


class RuleEngineTests(unittest.TestCase):
    def test_normal(self):
        r = evaluate_reading(97, 72, 1, 34.0)
        self.assertEqual(r["flags"], [])
        self.assertEqual(r["flag_count"], 0)
        self.assertEqual(r["verdict"], VERDICT_NORMAL)

    def test_critical_three_flags(self):
        r = evaluate_reading(88, 55, 0, 34.0)
        self.assertEqual(
            r["flags"], ["LOW_SPO2", "BRADYCARDIA", "NO_MOTION"]
        )
        self.assertEqual(r["flag_count"], 3)
        self.assertEqual(r["verdict"], VERDICT_CRITICAL)

    def test_moderate_bradycardia(self):
        r = evaluate_reading(92, 58, 1, 34.0)
        self.assertEqual(r["flags"], ["BRADYCARDIA"])
        self.assertEqual(r["flag_count"], 1)
        self.assertEqual(r["verdict"], VERDICT_MODERATE)

    def test_critical_spo2_and_fever(self):
        r = evaluate_reading(89, 75, 1, 36.0)
        self.assertEqual(r["flags"], ["LOW_SPO2", "FEVER_RANGE_TEMP"])
        self.assertEqual(r["flag_count"], 2)
        self.assertEqual(r["verdict"], VERDICT_CRITICAL)


if __name__ == "__main__":
    unittest.main()
