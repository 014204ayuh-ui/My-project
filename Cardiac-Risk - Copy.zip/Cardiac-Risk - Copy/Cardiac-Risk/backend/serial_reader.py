"""Open serial (or mock), parse CSV vitals, validate, score, append log, yield."""

from __future__ import annotations

import csv
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Optional

from rule_engine import (
    VERDICT_CRITICAL,
    VERDICT_MODERATE,
    VERDICT_NORMAL,
    evaluate_reading,
)

ROOT = Path(__file__).resolve().parent
LOG_PATH = ROOT / "logs" / "readings.csv"
LOG_FIELDS = [
    "timestamp",
    "spo2",
    "hb",
    "adm",
    "temp",
    "flags",
    "flag_count",
    "ml_risk_class",
    "ml_probability",
    "final_verdict",
]

SPO2_RANGE = (70.0, 100.0)
HB_RANGE = (40.0, 200.0)
ADM_OK = {0, 1}
TEMP_RANGE = (30.0, 42.0)

logger = logging.getLogger(__name__)

ML_VERDICT = {
    0: VERDICT_NORMAL,
    1: VERDICT_MODERATE,
    2: VERDICT_MODERATE,  # ML stays in the non-critical band; rules own CRITICAL
}


def _ensure_log() -> None:
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not LOG_PATH.exists():
        with LOG_PATH.open("w", newline="", encoding="utf-8") as fh:
            csv.DictWriter(fh, fieldnames=LOG_FIELDS).writeheader()


def append_row(row: dict) -> None:
    _ensure_log()
    with LOG_PATH.open("a", newline="", encoding="utf-8") as fh:
        csv.DictWriter(fh, fieldnames=LOG_FIELDS).writerow(
            {k: row.get(k, "") for k in LOG_FIELDS}
        )


def parse_line(line: str) -> dict:
    parts = {}
    for kv in line.split(","):
        if ":" not in kv:
            raise ValueError(f"bad token: {kv!r}")
        key, val = kv.split(":", 1)
        parts[key.strip().upper()] = val.strip()
    return {
        "spo2": float(parts["SPO2"]),
        "hb": float(parts["HB"]),
        "adm": int(float(parts["ADM"])),
        "temp": float(parts["TEMP"]),
    }


def in_range(spo2: float, hb: float, adm: int, temp: float) -> bool:
    return (
        SPO2_RANGE[0] <= spo2 <= SPO2_RANGE[1]
        and HB_RANGE[0] <= hb <= HB_RANGE[1]
        and adm in ADM_OK
        and TEMP_RANGE[0] <= temp <= TEMP_RANGE[1]
    )


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def warning_row(spo2, hb, adm, temp, reason: str = "OUT OF RANGE") -> dict:
    row = {
        "timestamp": _now(),
        "spo2": spo2,
        "hb": hb,
        "adm": adm,
        "temp": temp,
        "flags": "WARNING",
        "flag_count": 0,
        "ml_risk_class": "",
        "ml_probability": "",
        "final_verdict": f"WARNING - {reason}",
    }
    append_row(row)
    return row


def score_reading(spo2: float, hb: float, adm: int, temp: float) -> dict:
    from model import predict_risk

    rule = evaluate_reading(spo2, hb, adm, temp)
    ml = predict_risk(spo2, hb, adm, temp)
    if rule["flag_count"] >= 2:
        final = rule["verdict"]
    else:
        final = ML_VERDICT.get(ml["risk_class"], VERDICT_MODERATE)

    row = {
        "timestamp": _now(),
        "spo2": spo2,
        "hb": hb,
        "adm": adm,
        "temp": temp,
        "flags": "|".join(rule["flags"]),
        "flag_count": rule["flag_count"],
        "ml_risk_class": ml["risk_class"],
        "ml_probability": round(ml["probability"], 4),
        "final_verdict": final,
        "flags_list": rule["flags"],
    }
    append_row({k: row[k] for k in LOG_FIELDS})
    return row


def process_line(line: str) -> Optional[dict]:
    line = line.strip()
    if not line or line.startswith("ERR:"):
        return None
    try:
        vals = parse_line(line)
    except (ValueError, KeyError) as exc:
        logger.warning("parse fail %s: %s", line, exc)
        return warning_row("", "", "", "", reason="PARSE ERROR")

    spo2, hb, adm, temp = vals["spo2"], vals["hb"], vals["adm"], vals["temp"]
    if not in_range(spo2, hb, adm, temp):
        logger.warning("out of range: %s", line)
        return warning_row(spo2, hb, adm, temp)

    return score_reading(spo2, hb, adm, temp)


def read_loop(port: str, baud: int = 115200) -> Iterator[dict]:
    import serial

    ser = serial.Serial(port, baud, timeout=2)
    try:
        while True:
            raw = ser.readline()
            if not raw:
                continue
            try:
                line = raw.decode("utf-8", errors="replace").strip()
            except Exception:
                continue
            row = process_line(line)
            if row is not None:
                yield row
    finally:
        ser.close()


MOCK_LINES = [
    "SPO2:97,HB:72,ADM:1,TEMP:34.0",
    "SPO2:92,HB:58,ADM:1,TEMP:34.0",
    "SPO2:97,HB:72,ADM:1,TEMP:34.0",
    "SPO2:88,HB:55,ADM:0,TEMP:34.0",
    "SPO2:97,HB:80,ADM:1,TEMP:33.5",
    "SPO2:89,HB:75,ADM:1,TEMP:36.0",
    "SPO2:150,HB:72,ADM:1,TEMP:34",
    "SPO2:96,HB:70,ADM:1,TEMP:33.8",
]


def mock_loop(interval_s: float = 2.0) -> Iterator[dict]:
    i = 0
    while True:
        row = process_line(MOCK_LINES[i % len(MOCK_LINES)])
        if row is not None:
            yield row
        i += 1
        time.sleep(interval_s)
