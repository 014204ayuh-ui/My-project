"""Range-validation cases from the spec."""

import unittest
from unittest.mock import patch

import serial_reader


class SerialValidationTests(unittest.TestCase):
    def test_out_of_range_spo2_skips_prediction(self):
        with patch.object(serial_reader, "append_row"):
            row = serial_reader.process_line("SPO2:150,HB:72,ADM:1,TEMP:34")
        self.assertIn("WARNING", row["final_verdict"])
        self.assertEqual(row["flags"], "WARNING")
        self.assertEqual(row["ml_risk_class"], "")

    def test_valid_line_runs_pipeline(self):
        with patch.object(serial_reader, "score_reading", return_value={
            "timestamp": "t",
            "spo2": 97.0,
            "hb": 72.0,
            "adm": 1,
            "temp": 34.0,
            "flags": "",
            "flag_count": 0,
            "ml_risk_class": 0,
            "ml_probability": 0.12,
            "final_verdict": "NORMAL",
        }) as scored:
            row = serial_reader.process_line("SPO2:97,HB:72,ADM:1,TEMP:34")
        scored.assert_called_once_with(97.0, 72.0, 1, 34.0)
        self.assertEqual(row["final_verdict"], "NORMAL")

    def test_in_range_helper(self):
        self.assertTrue(serial_reader.in_range(97, 72, 1, 34))
        self.assertFalse(serial_reader.in_range(150, 72, 1, 34))


if __name__ == "__main__":
    unittest.main()
