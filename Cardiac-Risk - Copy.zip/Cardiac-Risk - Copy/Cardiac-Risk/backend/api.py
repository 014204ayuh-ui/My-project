"""FastAPI: latest reading, history, live WebSocket. Serial (or mock) in background."""

from __future__ import annotations

import asyncio
import csv
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from serial_reader import LOG_PATH, mock_loop, read_loop


def _load_env() -> None:
    env_path = Path(__file__).resolve().parent / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, val = line.split("=", 1)
        os.environ.setdefault(key.strip(), val.strip())


_load_env()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("api")

DISCLAIMER = (
    "This system provides risk stratification only, not medical diagnosis. "
    "All CRITICAL or MODERATE outputs direct the user to seek clinical "
    "evaluation from a qualified physician."
)

ERROR_SHAPE = {"ok": False, "error": "", "disclaimer": DISCLAIMER}

latest: dict[str, Any] | None = None
subscribers: set[WebSocket] = set()


def with_disclaimer(payload: dict) -> dict:
    out = dict(payload)
    out["disclaimer"] = DISCLAIMER
    out["ok"] = True
    return out


def row_to_json(row: dict) -> dict:
    flags = row.get("flags", "")
    if isinstance(flags, str) and flags and flags != "WARNING":
        flags_list = [f for f in flags.split("|") if f]
    elif isinstance(row.get("flags_list"), list):
        flags_list = row["flags_list"]
    else:
        flags_list = []
    return with_disclaimer(
        {
            "timestamp": row.get("timestamp"),
            "spo2": _num(row.get("spo2")),
            "hb": _num(row.get("hb")),
            "adm": _int_or_none(row.get("adm")),
            "temp": _num(row.get("temp")),
            "flags": flags_list if flags != "WARNING" else ["WARNING"],
            "flag_count": _int_or_none(row.get("flag_count")) or 0,
            "ml_risk_class": _int_or_none(row.get("ml_risk_class")),
            "ml_probability": _num(row.get("ml_probability")),
            "final_verdict": row.get("final_verdict"),
        }
    )


def _num(v):
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _int_or_none(v):
    if v is None or v == "":
        return None
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return None


def read_history(limit: int) -> list[dict]:
    if not LOG_PATH.exists():
        return []
    with LOG_PATH.open("r", newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh, fieldnames=None))
    return rows[-limit:] if limit else rows


async def broadcast(row: dict) -> None:
    payload = row_to_json(row)
    dead = []
    for ws in subscribers:
        try:
            await ws.send_json(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        subscribers.discard(ws)


async def reader_task() -> None:
    global latest
    mock = os.environ.get("MOCK_SERIAL", "1").strip() not in ("0", "false", "False")
    port = os.environ.get("SERIAL_PORT", "").strip()
    baud = int(os.environ.get("SERIAL_BAUD", "115200"))

    def blocking_iter():
        if mock or not port:
            logger.info("serial: MOCK_SERIAL loop")
            return mock_loop()
        logger.info("serial: %s @ %s", port, baud)
        return read_loop(port, baud)

    loop = asyncio.get_running_loop()
    it = blocking_iter()

    def next_row():
        try:
            return next(it)
        except StopIteration:
            return None

    while True:
        try:
            row = await loop.run_in_executor(None, next_row)
        except Exception as exc:
            logger.exception("reader error: %s", exc)
            await asyncio.sleep(2)
            continue
        if row is None:
            break
        latest = row
        await broadcast(row)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    task = asyncio.create_task(reader_task())
    yield
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


app = FastAPI(title="Cardiac Arrest Risk Prediction", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/reading/latest")
def reading_latest():
    if latest is None:
        hist = read_history(1)
        if not hist:
            return JSONResponse(
                status_code=404,
                content={
                    **ERROR_SHAPE,
                    "error": "no readings yet",
                },
            )
        return row_to_json(hist[-1])
    return row_to_json(latest)


@app.get("/history")
def history(limit: int = Query(20, ge=1, le=500)):
    rows = read_history(limit)
    return with_disclaimer({"count": len(rows), "readings": [row_to_json(r) for r in reversed(rows)]})


@app.websocket("/ws/live")
async def ws_live(ws: WebSocket):
    await ws.accept()
    subscribers.add(ws)
    if latest is not None:
        try:
            await ws.send_json(row_to_json(latest))
        except Exception:
            pass
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        subscribers.discard(ws)
