"""Deterministic hard-threshold safety layer.

Runs before the ML model. Two or more simultaneous abnormal vitals force a
CRITICAL verdict regardless of model output.
"""

from __future__ import annotations

VERDICT_NORMAL = "NORMAL"
VERDICT_MODERATE = "MODERATE - MONITOR CLOSELY"
VERDICT_CRITICAL = (
    "CRITICAL - CARDIAC ARREST RISK - CONSULT DOCTOR IMMEDIATELY"
)

SPO2_LOW = 90.0
HB_BRADY = 60.0
TEMP_FEVER_SKIN = 35.0


def evaluate_reading(
    spo2: float, hb: float, adm: int, temp: float
) -> dict:
    """Return flags + verdict for an already-validated reading.

    Assumes serial_reader has already range-checked the values.
    """
    flags: list[str] = []

    if spo2 < SPO2_LOW:
        flags.append("LOW_SPO2")
    if hb < HB_BRADY:
        flags.append("BRADYCARDIA")
    if adm == 0:
        flags.append("NO_MOTION")
    if temp > TEMP_FEVER_SKIN:
        flags.append("FEVER_RANGE_TEMP")

    flag_count = len(flags)
    if flag_count >= 2:
        verdict = VERDICT_CRITICAL
    elif flag_count == 1:
        verdict = VERDICT_MODERATE
    else:
        verdict = VERDICT_NORMAL

    return {
        "flags": flags,
        "flag_count": flag_count,
        "verdict": verdict,
    }
