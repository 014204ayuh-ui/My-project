"""Load trained RandomForest + scaler; infer risk class for one reading."""

from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "trained_model.pkl"
SCALER_PATH = ROOT / "scaler.pkl"

_model = None
_scaler = None


def _load() -> tuple:
    global _model, _scaler
    if _model is None or _scaler is None:
        if not MODEL_PATH.exists() or not SCALER_PATH.exists():
            raise FileNotFoundError(
                "trained_model.pkl / scaler.pkl missing — run train_model.py first"
            )
        _model = joblib.load(MODEL_PATH)
        _scaler = joblib.load(SCALER_PATH)
    return _model, _scaler


def predict_risk(spo2: float, hb: float, adm: int, temp: float) -> dict:
    """Return risk_class 0|1|2 and P(positive class)."""
    model, scaler = _load()
    X = np.array([[spo2, hb, adm, temp]], dtype=float)
    X_scaled = scaler.transform(X)
    proba = model.predict_proba(X_scaled)[0]
    p1 = float(proba[1]) if len(proba) > 1 else float(proba[0])
    if p1 < 0.3:
        risk_class = 0
    elif p1 < 0.6:
        risk_class = 1
    else:
        risk_class = 2
    return {"risk_class": risk_class, "probability": p1}
