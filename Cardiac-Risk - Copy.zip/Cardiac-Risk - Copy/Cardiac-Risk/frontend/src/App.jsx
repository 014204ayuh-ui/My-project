import { useEffect, useMemo, useRef, useState } from "react";

const DISCLAIMER =
  "This system provides risk stratification only, not medical diagnosis. All CRITICAL or MODERATE outputs direct the user to seek clinical evaluation from a qualified physician.";

const API_BASE = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000";
const WS_URL = import.meta.env.VITE_WS_URL || "ws://127.0.0.1:8000/ws/live";

function verdictLevel(verdict) {
  const v = (verdict || "").toUpperCase();
  if (v.startsWith("CRITICAL")) return "critical";
  if (v.startsWith("MODERATE")) return "moderate";
  if (v.startsWith("WARNING")) return "warning";
  if (v.startsWith("NORMAL")) return "normal";
  return "idle";
}

function fmt(n, digits = 0) {
  if (n === null || n === undefined || Number.isNaN(Number(n))) return "···";
  return Number(n).toFixed(digits);
}

function tsLabel(ts) {
  if (!ts) return "—";
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return String(ts).slice(11, 19);
  return d.toISOString().slice(11, 19);
}

export default function App() {
  const [current, setCurrent] = useState(null);
  const [log, setLog] = useState([]);
  const [connected, setConnected] = useState(false);
  const wsRef = useRef(null);
  const retryRef = useRef(0);

  const pushReading = (row) => {
    setCurrent(row);
    setLog((prev) => {
      const next = [row, ...prev.filter((r) => r.timestamp !== row.timestamp)];
      return next.slice(0, 20);
    });
  };

  useEffect(() => {
    let stop = false;
    let timer;

    fetch(`${API_BASE}/history?limit=20`)
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (stop || !data?.readings?.length) return;
        setLog(data.readings.slice(0, 20));
        setCurrent(data.readings[0]);
      })
      .catch(() => {});

    const connect = () => {
      if (stop) return;
      const ws = new WebSocket(WS_URL);
      wsRef.current = ws;
      ws.onopen = () => {
        setConnected(true);
        retryRef.current = 0;
      };
      ws.onmessage = (ev) => {
        try {
          pushReading(JSON.parse(ev.data));
        } catch {
          /* ignore malformed frames */
        }
      };
      ws.onclose = () => {
        setConnected(false);
        const wait = Math.min(8000, 500 * 2 ** retryRef.current);
        retryRef.current += 1;
        timer = window.setTimeout(connect, wait);
      };
      ws.onerror = () => ws.close();
    };

    connect();
    return () => {
      stop = true;
      window.clearTimeout(timer);
      wsRef.current?.close();
    };
  }, []);

  const flags = current?.flags || [];
  const level = verdictLevel(current?.final_verdict);

  useEffect(() => {
    document.body.dataset.verdict = level;
    return () => {
      delete document.body.dataset.verdict;
    };
  }, [level]);

  const vitals = useMemo(
    () => [
      {
        id: "spo2",
        label: "SpO2",
        unit: "%",
        value: fmt(current?.spo2, 0),
        flag: "LOW_SPO2",
      },
      {
        id: "hb",
        label: "HR",
        unit: "bpm",
        value: fmt(current?.hb, 0),
        flag: "BRADYCARDIA",
      },
      {
        id: "adm",
        label: "ADM",
        unit: current?.adm === 0 ? "no motion" : "motion",
        value:
          current?.adm === 0 ? "STABLE" : current?.adm === 1 ? "FALL" : "···",
        flag: "NO_MOTION",
      },
      {
        id: "temp",
        label: "TEMP",
        unit: "°C skin",
        value: fmt(current?.temp, 1),
        flag: "FEVER_RANGE_TEMP",
      },
    ],
    [current]
  );

  return (
    <div
      className={`monitor verdict-${level}`}
      data-verdict={level}
      role="main"
    >
      <div className="alarm-glow" aria-hidden="true" />

      <header className="strip" aria-label="Live vitals">
        <span className="paddle paddle-start" aria-hidden="true" />
        {vitals.map((v, i) => {
          const flagged = flags.includes(v.flag);
          return (
            <section
              key={v.id}
              data-vital={v.id}
              className={`vital${flagged ? " flagged" : ""}`}
              aria-label={`${v.label} ${v.value} ${v.unit}`}
            >
              {i > 0 ? <span className="hairline" aria-hidden="true" /> : null}
              <div
                className={`vital-num${v.value === "···" ? " waiting" : ""}`}
              >
                {v.value}
              </div>
              <div className="vital-meta">
                <span className="vital-label">{v.label}</span>
                <span className="vital-unit">{v.unit}</span>
              </div>
            </section>
          );
        })}
        <span className="paddle paddle-end" aria-hidden="true" />
      </header>

      <p className="verdict-line" aria-live="assertive" aria-atomic="true">
        <span className="conn" data-on={connected ? "1" : "0"}>
          <span className="led" aria-hidden="true" />
          {connected ? "LIVE" : "SEEKING"}
        </span>
        <span className="verdict-text">
          {current?.final_verdict || "NO SIGNAL"}
        </span>
      </p>

      <section className="log" aria-label="Reading log, newest first">
        <table>
          <thead>
            <tr>
              <th>TIME</th>
              <th>SPO2</th>
              <th>HR</th>
              <th>ADM</th>
              <th>TEMP</th>
              <th>VERDICT</th>
            </tr>
          </thead>
          <tbody>
            {log.length === 0 ? (
              <tr>
                <td colSpan={6} className="empty">
                  No readings yet
                </td>
              </tr>
            ) : (
              log.map((row) => (
                <tr
                  key={row.timestamp}
                  data-level={verdictLevel(row.final_verdict)}
                >
                  <td>{tsLabel(row.timestamp)}</td>
                  <td>{fmt(row.spo2, 0)}</td>
                  <td>{fmt(row.hb, 0)}</td>
                  <td>
                    {row.adm === 0 ? "0" : row.adm === 1 ? "1" : "···"}
                  </td>
                  <td>{fmt(row.temp, 1)}</td>
                  <td>{row.final_verdict}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </section>

      <footer className="disclaimer">{DISCLAIMER}</footer>
    </div>
  );
}
