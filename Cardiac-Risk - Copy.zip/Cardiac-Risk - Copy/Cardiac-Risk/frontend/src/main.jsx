import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { applyTheme } from "./themes/config.js";
import "./index.css";
import "./themes/crash.css";
import "./themes/night.css";
import "./themes/linen.css";

applyTheme();

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
