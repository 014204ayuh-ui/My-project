/** Dashboard skins. Set VITE_THEME in frontend/.env or ?theme= on the URL. */

export const THEMES = {
  night: "First UI — charcoal + cyan IntelliVue night",
  linen: "Second UI — daylight ECG paper chart",
  crash: "Current UI — crash-cart umber + gold",
};

export const ALIASES = {
  first: "night",
  cyan: "night",
  intellivue: "night",
  monitor: "night",
  paper: "linen",
  chart: "linen",
  ecg: "linen",
  current: "crash",
  cart: "crash",
  default: "crash",
};

export const DEFAULT_THEME = "crash";

export function resolveTheme(raw) {
  const key = String(raw || "")
    .trim()
    .toLowerCase();
  if (THEMES[key]) return key;
  if (ALIASES[key]) return ALIASES[key];
  return DEFAULT_THEME;
}

export function applyTheme() {
  const query = new URLSearchParams(window.location.search).get("theme");
  const env = import.meta.env.VITE_THEME;
  const name = resolveTheme(query || env || DEFAULT_THEME);
  document.documentElement.dataset.theme = name;
  document.body.dataset.theme = name;
  document.title = `Cardiac Arrest Risk Monitor · ${name}`;
  return name;
}
