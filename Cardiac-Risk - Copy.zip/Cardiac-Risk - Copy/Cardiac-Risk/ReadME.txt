Build details

cd backend
pip install -r requirements.txt
copy .env.example .env
python train_model.py          # skip if trained_model.pkl already here
python -m uvicorn api:app --reload --port 8000


cd frontend
npm install
copy .env.example .env
npm run dev

Open http://localhost:5173


Default: mock serial (`MOCK_SERIAL=1` in `backend/.env`) — no hardware needed.
Change the MOCK_SERIAL value for hardware.


Themes:

- http://localhost:5173/?theme=night
- http://localhost:5173/?theme=linen
- http://localhost:5173/?theme=crash


For harwadre below example for env file

MOCK_SERIAL=0
SERIAL_PORT=COM3
SERIAL_BAUD=115200